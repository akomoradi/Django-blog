from django.db import models

from django.db import models 
from datetime import date

# Create your models here.
class BlogArticle(models.Model):
    title = models.CharField(max_length=50)
    coverImage =  models.ImageField( upload_to=None, height_field=None, width_field=None, max_length=None)
    body = models.TextField(null=True)
    slug= models.SlugField()
    datePublished = models.DateField(null=True) #when it was published
    isPublished = models.BooleanField(default=False)

    def publish(self):
        self.isPublished = True
        self.datePublished = datetime.utcnow()
        self.save()
    
    def unpublish(self):
        self.isPublished = False
        self.datePublished = None
        self.save()
    
    def __str__(self):
        return self.title


