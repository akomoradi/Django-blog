from django.shortcuts import render
from blog.models import BlogArticle

def indexing (request):
    articles = BlogArticle.objects.all().order_by('datePublished')
    context = {
        "Articles":articles,
    }

    return render(request , "blog/blog.html" , context)

def Detail(request , pk):
    article = BlogArticle.objects.get(pk=pk)
    context = {
        "Article": article,

    }
    return render(request , "blog/detail.html " ,context)