from django.urls import path 
from blog.views import indexing , Detail

urlpatterns = [
    path("blog/", indexing, name="blog"),
    path("<int:pk>/", Detail, name="blog"),
]
